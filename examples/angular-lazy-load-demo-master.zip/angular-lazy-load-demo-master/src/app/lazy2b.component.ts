import { Component } from "@angular/core";

@Component({
  template: `
    <p>lazy2b component</p>
  `
})
export class Lazy2bComponent {}
