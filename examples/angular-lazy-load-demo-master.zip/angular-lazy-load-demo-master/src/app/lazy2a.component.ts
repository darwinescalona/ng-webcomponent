import { Component } from "@angular/core";

@Component({
  template: `
    <p>lazy2a component</p>
  `
})
export class Lazy2aComponent {}
